package main.game.map;

public class Monster extends Obstacle{
	public static String CHARACTER = "M";

	public Monster (Point coordinates) {
		super(coordinates);
	}
}
