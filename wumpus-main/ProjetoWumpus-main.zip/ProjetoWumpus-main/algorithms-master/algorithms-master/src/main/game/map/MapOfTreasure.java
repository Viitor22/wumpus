package main.game.map;

public class MapOfTreasure extends Obstacle{
	public static String CHARACTER = "B";
	public MapOfTreasure(Point coordinates) {
		super(coordinates);
	}

}
