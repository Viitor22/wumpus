/**
 * 
 */
/**
 * 
 */
module WumpusSimulator {
}